# shellcheck shell=bash
# Reads /etc/devmagic-panel/config.env without sourcing it.
#
# Only known keys are accepted and every value must be a plain token or an
# absolute path, so a broken or hostile file cannot run code. When running as
# root the location is fixed; DMP_CONFIG is honoured only for non-root runs,
# which is how the bats tests point the scripts at a temporary tree.

DMP_DEFAULT_CONFIG="/etc/devmagic-panel/config.env"

DMP_CONFIG_KEYS=(
  PANEL_USER PANEL_GROUP PANEL_PORT PANEL_DOMAIN
  WEB_DIR WEB_GROUP
  CERTS_DIR CA_DIR
  APACHE_SITES_AVAILABLE APACHE_SITES_ENABLED APACHE_LOG_DIR
  HOSTS_FILE SYSTEM_CA_DIR BACKUP_DIR
)

# Keys added after the first release; older config files leave them out and get these defaults.
# UPDATE_REPO and UPDATE_GIT_URL are the panel's (where it updates from); dmp-root only accepts them.
DMP_CONFIG_OPTIONAL_KEYS=(PHP_CONF_DIR PHP_LIB_DIR STATE_DIR UPDATE_REPO UPDATE_GIT_URL
  NGINX_SITES_AVAILABLE NGINX_SITES_ENABLED NGINX_LOG_DIR NGINX_ADDRESS APACHE_ADDRESS MYSQL_CONF_DIR
  BINFMT_DIR WSL_INIT NGINX_WSL_HTTP_PORT NGINX_WSL_HTTPS_PORT)
# Under WSL: the kernel's binfmt_misc, where WSL registers its interop with
# Windows programs, and WSL's init, which runs them. Keys only so the tests can
# point wsl-interop at a temp tree; install.sh never writes them.
DMP_DEFAULT_BINFMT_DIR="/proc/sys/fs/binfmt_misc"
DMP_DEFAULT_WSL_INIT="/init"
# Under WSL, nginx answers for Windows on 127.0.0.1 on these ports too (WSL
# forwards 127.0.0.1 to Windows, not 127.0.0.2), and Windows relays its own
# 127.0.0.2:80 and :443 there (the helper's portproxy-on).
DMP_DEFAULT_NGINX_WSL_HTTP_PORT="8080"
DMP_DEFAULT_NGINX_WSL_HTTPS_PORT="8443"
DMP_DEFAULT_PHP_CONF_DIR="/etc/php"
# Where Debian keeps each version's packaged php.ini (php.ini-production), to compare and restore.
DMP_DEFAULT_PHP_LIB_DIR="/usr/lib/php"
DMP_DEFAULT_STATE_DIR="/var/lib/devmagic-panel"
DMP_DEFAULT_NGINX_SITES_AVAILABLE="/etc/nginx/sites-available"
DMP_DEFAULT_NGINX_SITES_ENABLED="/etc/nginx/sites-enabled"
DMP_DEFAULT_NGINX_LOG_DIR="/var/log/nginx"
# MySQL's (or MariaDB's) config root, with mysql.conf.d or mariadb.conf.d in it.
DMP_DEFAULT_MYSQL_CONF_DIR="/etc/mysql"
# nginx and Apache each answer on their own loopback address once nginx is set up.
DMP_DEFAULT_NGINX_ADDRESS="127.0.0.2"
DMP_DEFAULT_APACHE_ADDRESS="127.0.0.1"

# An address in 127.0.0.0/8 but 127.0.1.1, which Debian gives the machine's own name.
dmp_is_loopback_address() {
  local a="$1" octet
  [[ "$a" =~ ^127\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})$ && "$a" != 127.0.1.1 ]] || return 1
  for octet in "${BASH_REMATCH[@]:1}"; do
    (( 10#$octet <= 255 )) || return 1
  done
}

dmp_config_file() {
  if [[ $EUID -eq 0 ]]; then
    printf '%s' "$DMP_DEFAULT_CONFIG"
  else
    printf '%s' "${DMP_CONFIG:-$DMP_DEFAULT_CONFIG}"
  fi
}

dmp_is_config_key() {
  local key="$1" k
  for k in "${DMP_CONFIG_KEYS[@]}" "${DMP_CONFIG_OPTIONAL_KEYS[@]}"; do
    [[ "$k" == "$key" ]] && return 0
  done
  return 1
}

dmp_load_config() {
  local file key value line
  file="$(dmp_config_file)"
  [[ -f "$file" ]] || dmp_die "config not found: $file (run install.sh first)"

  while IFS= read -r line || [[ -n "$line" ]]; do
    [[ -z "$line" || "$line" == \#* ]] && continue
    [[ "$line" =~ ^([A-Z_]+)=([A-Za-z0-9._/@:-]*)$ ]] || dmp_die "invalid line in $file: $line"
    key="${BASH_REMATCH[1]}"
    value="${BASH_REMATCH[2]}"
    dmp_is_config_key "$key" || dmp_die "unknown key in $file: $key"
    printf -v "$key" '%s' "$value"
  done < "$file"

  for key in "${DMP_CONFIG_KEYS[@]}"; do
    [[ -n "${!key:-}" ]] || dmp_die "missing key in $file: $key"
  done
  PHP_CONF_DIR="${PHP_CONF_DIR:-$DMP_DEFAULT_PHP_CONF_DIR}"
  PHP_LIB_DIR="${PHP_LIB_DIR:-$DMP_DEFAULT_PHP_LIB_DIR}"
  STATE_DIR="${STATE_DIR:-$DMP_DEFAULT_STATE_DIR}"
  NGINX_SITES_AVAILABLE="${NGINX_SITES_AVAILABLE:-$DMP_DEFAULT_NGINX_SITES_AVAILABLE}"
  NGINX_SITES_ENABLED="${NGINX_SITES_ENABLED:-$DMP_DEFAULT_NGINX_SITES_ENABLED}"
  NGINX_LOG_DIR="${NGINX_LOG_DIR:-$DMP_DEFAULT_NGINX_LOG_DIR}"
  MYSQL_CONF_DIR="${MYSQL_CONF_DIR:-$DMP_DEFAULT_MYSQL_CONF_DIR}"
  NGINX_ADDRESS="${NGINX_ADDRESS:-$DMP_DEFAULT_NGINX_ADDRESS}"
  APACHE_ADDRESS="${APACHE_ADDRESS:-$DMP_DEFAULT_APACHE_ADDRESS}"
  BINFMT_DIR="${BINFMT_DIR:-$DMP_DEFAULT_BINFMT_DIR}"
  WSL_INIT="${WSL_INIT:-$DMP_DEFAULT_WSL_INIT}"
  NGINX_WSL_HTTP_PORT="${NGINX_WSL_HTTP_PORT:-$DMP_DEFAULT_NGINX_WSL_HTTP_PORT}"
  NGINX_WSL_HTTPS_PORT="${NGINX_WSL_HTTPS_PORT:-$DMP_DEFAULT_NGINX_WSL_HTTPS_PORT}"
  for key in WEB_DIR CERTS_DIR CA_DIR APACHE_SITES_AVAILABLE APACHE_SITES_ENABLED \
    APACHE_LOG_DIR HOSTS_FILE SYSTEM_CA_DIR BACKUP_DIR PHP_CONF_DIR PHP_LIB_DIR STATE_DIR \
    NGINX_SITES_AVAILABLE NGINX_SITES_ENABLED NGINX_LOG_DIR MYSQL_CONF_DIR BINFMT_DIR WSL_INIT; do
    [[ "${!key}" == /* && "${!key}" != *..* ]] || dmp_die "$key must be an absolute path: ${!key}"
  done
  for key in NGINX_ADDRESS APACHE_ADDRESS; do
    dmp_is_loopback_address "${!key}" || dmp_die "$key must be an address in 127.0.0.0/8 other than 127.0.1.1: ${!key}"
  done
  [[ "$NGINX_ADDRESS" != "$APACHE_ADDRESS" ]] || dmp_die "NGINX_ADDRESS and APACHE_ADDRESS must differ"
  [[ "$PANEL_PORT" =~ ^[0-9]{2,5}$ ]] || dmp_die "PANEL_PORT must be a number: $PANEL_PORT"
  for key in NGINX_WSL_HTTP_PORT NGINX_WSL_HTTPS_PORT; do
    if [[ ! "${!key}" =~ ^[0-9]{4,5}$ ]] || (( 10#${!key} < 1024 || 10#${!key} > 65535 )); then
      dmp_die "$key must be a port from 1024 to 65535: ${!key}"
    fi
    [[ "${!key}" != "$PANEL_PORT" ]] || dmp_die "$key must differ from PANEL_PORT: ${!key}"
  done
  [[ "$NGINX_WSL_HTTP_PORT" != "$NGINX_WSL_HTTPS_PORT" ]] || dmp_die "NGINX_WSL_HTTP_PORT and NGINX_WSL_HTTPS_PORT must differ"
}
